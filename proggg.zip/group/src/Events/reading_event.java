package Events;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import org.bson.Document;

import com.google.gson.Gson;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class reading_event {
	public ArrayList<Event> readdatabase(){
		

		ArrayList<Event> events = new ArrayList<>();
		MongoClient client = new MongoClient("localhost", 27017);
		MongoDatabase database = client.getDatabase("config");
		MongoCollection<Document> collection = database.getCollection("x");
		
		FindIterable<Document> docs = collection.find(); 
        for (Document doc : docs) {
    		String inputLine = doc.toJson();
    		Gson gson = new Gson(); 
        	Event obj = gson.fromJson(inputLine, Event.class);	
        	events.add(obj);
        }
		client.close();
		
		
		Connection conn2 = null;
		PreparedStatement preparedStmt2 = null;
		PreparedStatement preparedStmt3 = null;
		
		try
	    {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn2 = DriverManager.getConnection("jdbc:mysql://localhost/hw3?&serverTimezone=America/Los_Angeles&user=root&password=hellodear&useSSL=false");
			String myDriver = "com.mysql.cj.jdbc.Driver";
		      Class.forName(myDriver);
	      
	    //System.out.println(username_ + " " + search);
		      
		      String query2 = "DELETE FROM Likes";
		      preparedStmt3 = conn2.prepareStatement(query2);
		      preparedStmt3.executeUpdate();
		   
		      
		      
		      for (Event e: events) {
			      String query = "INSERT INTO Likes (event, num_likes) VALUES (?, ?)";
			      preparedStmt2 = conn2.prepareStatement(query);
			      preparedStmt2.setString (1, e.getTitle());
			      preparedStmt2.setInt (2, e.getLike());
			      preparedStmt2.executeUpdate();
		      }
	   
	    
			} catch (SQLException sqle) {
				System.out.println ("SQLException: " + sqle.getMessage());
			} catch (ClassNotFoundException cnfe) {
				System.out.println ("ClassNotFoundException: " + cnfe.getMessage());
			} 

	    finally {
		     
		     try {

					if (preparedStmt2 != null) {
						preparedStmt2.close();
					}
					if (preparedStmt3 != null) {
						preparedStmt3.close();
					}
					
					if (conn2 != null) {
						conn2.close();
					}
				} catch (SQLException sqle) {
					System.out.println("sqle: " + sqle.getMessage());
				}
	    }
		
		
		return events;
	}
}
