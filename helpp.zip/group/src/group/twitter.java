package group;


import java.util.ArrayList;
import java.util.List;

import twitter4j.Query;
import twitter4j.QueryResult;
import twitter4j.Status;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.auth.AccessToken;



public class twitter {
	
	public twitter(){}
	public ArrayList<tweet> search(String search){
		Twitter twitter = new TwitterFactory().getInstance();

        AccessToken accessToken = new AccessToken("1096282590544183296-X0eOUmLkgG4IDu8DNuhcdOkVktphSL", "WNQ64Xp9Ti4nB4NlazdnKs35T2efHtN623NG4Rc3k6XMm");
        twitter.setOAuthConsumer("aUbmyb5kXhD4bCEE8JKMmIibX", "LZ19f8HT41lKMbruw4tAePQekERJduaXEZE54Ca402TyvNnSfj");
        twitter.setOAuthAccessToken(accessToken);
        ArrayList<tweet> my_tweets = new ArrayList<>();
        try {
            Query query = new Query(search);
            query.setCount(10);
            QueryResult result;
            int flag = 0;
            do {
                result = twitter.search(query);
                List<Status> tweets = result.getTweets();
               // int count = 0;
	                for (Status tweet : tweets) {
	                	tweet x = new tweet(tweet.getText(), tweet.getUser().getScreenName(), tweet.getCreatedAt());
	                	my_tweets.add(x);
	                	//count++;
	                   // System.out.println("@" + tweet.getUser().getScreenName() + " - " + tweet.getText() + "-" + tweet.getCreatedAt());
	                }
	             
                flag = 1;
                
            } while ((query = result.nextQuery()) != null && flag != 1);
            return my_tweets;
        } catch (TwitterException te) {
            te.printStackTrace();
            System.out.println("Failed to search tweets: " + te.getMessage());
            System.exit(-1);
        }
		return my_tweets;
	}
	
	 public static void main(String[] args) {
		 twitter x = new twitter();
		 ArrayList<tweet> my_tweets = new ArrayList<>();
		 
		 my_tweets = x.search("A conversation with Mahershala Ali");
		 System.out.println(my_tweets.size());
		 for (int i = 0; i < my_tweets.size(); i++) {
			 System.out.println(my_tweets.get(i).tweet);
		 }
	 }

}