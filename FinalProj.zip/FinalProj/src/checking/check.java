package checking;


import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class check {
	
		
    private static String DBstring()  {
		return "jdbc:MySQL80://localhost::3306/freefood?user=root&password=root";//&useSSL=false";
    }
    
    public static boolean emailcheck(String email)   {


    	if(email.indexOf((char)34)!=-1) {return false;}
       	if(email.indexOf((char)39)!=-1) {return false;}
       	if(email.indexOf("..")!=-1) {return false;}

    	int atS = email.indexOf('@');
    	if(atS>0) {
        	if (email.indexOf('@',atS+1)>0) {return false;}
    		int dotS = email.indexOf(".",atS+2); 
    		if( dotS>0 && dotS< email.length()-1){
         		return true;
         	}
    	}
		return false;
    }

    	
    public static boolean passwordcheck(String Pass)   {
        int ps=0;

    	if(Pass.indexOf((char)34)!=-1) {return false;}
    	if(Pass.indexOf((char)39)!=-1) {return false;}
        
        
        ps=ps+Pass.indexOf('1')+Pass.indexOf('2')+Pass.indexOf('3')+Pass.indexOf('4')+Pass.indexOf('5');
        ps=ps+Pass.indexOf('6')+Pass.indexOf('7')+Pass.indexOf('8')+Pass.indexOf('9')+Pass.indexOf('0');
    	if(ps == -10) {	return false;}
    	
    	ps=0;
        ps=ps+Pass.indexOf('.')+Pass.indexOf('?')+Pass.indexOf('!')+Pass.indexOf(',')+Pass.indexOf('%');
        ps=ps+Pass.indexOf('$')+Pass.indexOf('#')+Pass.indexOf('@')+Pass.indexOf('*')+Pass.indexOf('(');
        ps=ps+Pass.indexOf(')')+Pass.indexOf('_')+Pass.indexOf('-')+Pass.indexOf('<')+Pass.indexOf('>');
    	if(ps == -15) { return false;}

    	ps=0;
        ps=ps+Pass.indexOf('a')+Pass.indexOf('b')+Pass.indexOf('c')+Pass.indexOf('d')+Pass.indexOf('e');
        ps=ps+Pass.indexOf('f')+Pass.indexOf('g')+Pass.indexOf('h')+Pass.indexOf('i')+Pass.indexOf('j');
        ps=ps+Pass.indexOf('k')+Pass.indexOf('l')+Pass.indexOf('m')+Pass.indexOf('n')+Pass.indexOf('o');
        ps=ps+Pass.indexOf('p')+Pass.indexOf('q')+Pass.indexOf('r')+Pass.indexOf('s')+Pass.indexOf('t');
        ps=ps+Pass.indexOf('u')+Pass.indexOf('v')+Pass.indexOf('w')+Pass.indexOf('x')+Pass.indexOf('y')+Pass.indexOf('z');
    	if(ps == -26) {	return false;}

    	ps=0;
        ps=ps+Pass.indexOf('A')+Pass.indexOf('B')+Pass.indexOf('C')+Pass.indexOf('D')+Pass.indexOf('E');
        ps=ps+Pass.indexOf('F')+Pass.indexOf('G')+Pass.indexOf('H')+Pass.indexOf('I')+Pass.indexOf('J');
        ps=ps+Pass.indexOf('K')+Pass.indexOf('L')+Pass.indexOf('M')+Pass.indexOf('N')+Pass.indexOf('O');
        ps=ps+Pass.indexOf('P')+Pass.indexOf('Q')+Pass.indexOf('R')+Pass.indexOf('S')+Pass.indexOf('T');
        ps=ps+Pass.indexOf('U')+Pass.indexOf('V')+Pass.indexOf('W')+Pass.indexOf('X')+Pass.indexOf('Y')+Pass.indexOf('Z');
    	if(ps == -26) {	return false;}
    	    	
    	return true;
    }
    
    private static Connection DBconection() throws SQLException  {
		Connection conn = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		    conn = DriverManager.getConnection(DBstring());
		} catch (ClassNotFoundException e) {
			return null;
		}
    	return conn;
    }
    public static int login(String username, String password) {
			Connection conn      = null;
			Statement st         = null;
			PreparedStatement ps = null;
			ResultSet rs         = null;
			try {
//			    conn = DriverManager.getConnection(DBstring());
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
				    conn = DriverManager.getConnection(DBstring());
				} catch (ClassNotFoundException e) {
					return -2;
					//conn = null;
				}
		        if(conn==null) {
                	return -1;
                }
				st = conn.createStatement();
				String name = username;
				ps = conn.prepareStatement("SELECT * FROM usertable WHERE username = ?");
				ps.setString(1, name); // set first variable in prepared statement
				rs = ps.executeQuery();
//				while (rs.next()) {
				if (rs.next()) {
					String found_name = rs.getString("userName");
					String found_pass = rs.getString("Password");

					if (found_pass !=null && found_pass.equals(password)) {
						return 1; //VERIFIED
					}
					else {
					    return 3;//Password no good
					}
				}
				else {
					return 2;// user does not exist
				}
					
			} catch (SQLException sqle) {
//				System.out.println("sqle: Error in conection" );//+ sqle.getMessage());
                return -3;
			} 
			finally {
				try {
					if (rs != null) {
						rs.close();
					}
					if (st != null) {
						st.close();
					}
					if (ps != null) {
						ps.close();
					}
					if (conn != null) {
						conn.close();
					}
				} catch (SQLException sqle) {
//					return -1;
					System.out.println("sqle: Error in conection" );//+ sqle.getMessage());
				}
			}		
//			return 2;
		}
	
	public static String validation(String username, String password){
		Connection conn = null;
		Statement st = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		PreparedStatement ps2 = null;
		try {
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
			    conn = DriverManager.getConnection(DBstring());
			} catch (ClassNotFoundException e) {
            	return "sqle:Device Error in conection"; // false;
			}
	        if(conn==null) {
				System.out.println("sqle: Error in conection" );//+ sqle.getMessage());
            	return "sqle: Error in conection"; // false;
            }
			st = conn.createStatement();
			String name = username;
			ps = conn.prepareStatement("SELECT * FROM UserTable WHERE userName=?");
			ps.setString(1, name); // set first variable in prepared statement
			rs = ps.executeQuery();
//			while (rs.next()) {
			if(rs.next()) {
				String found_name = rs.getString("userName");
				if (found_name != null) {
					return "This username is already taken.";//false;
				}
			}

//			ps2 = conn.prepareStatement("INSERT INTO UserTable (userName, Password) VALUES (?, ?)");
//			ps2.setString(1, username);
//			ps2.setString(2, password);
//			ps2.executeUpdate();
			
			return "";//true;
				
		} catch (SQLException sqle) {
				System.out.println ("SQLException: " + sqle.getMessage());
	        	return "sqle:SQL exacution Error "; // false;
//		} catch (ClassNotFoundException cnfe) {
//			System.out.println ("ClassNotFoundException: " + cnfe.getMessage());
		} 
		finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (st != null) {
					st.close();
				}
				if (ps != null) {
					ps.close();
				}
				if (ps2 != null) {
					ps2.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException sqle) {
				System.out.println("sqle: Error in conection" );//+ sqle.getMessage());
//				System.out.println("sqle: " + sqle.getMessage());
			}
		}
	}
	
public static int addUser(String username, String password){
	 	Connection conn = null;
		PreparedStatement preparedStmt = null;
		
		try
	    {
//			Class.forName("com.mysql.cj.jdbc.Driver");
//		    conn = DriverManager.getConnection(DBstring());
			conn = DBconection();
            if(conn==null) {
            	return 1;
            }
 
	        String query = "INSERT INTO userTable (username, password) VALUES (?, ?))";
	        preparedStmt = conn.prepareStatement(query);
	        preparedStmt.setString (1, username);
     	    preparedStmt.setString (2, password);
	        preparedStmt.executeUpdate();    
		} catch (SQLException sqle) {
        	return -1;

			//			System.out.println ("SQLException: " + sqle.getMessage());
//			} catch (ClassNotFoundException cnfe) {
//				System.out.println ("ClassNotFoundException: " + cnfe.getMessage());
//			} 
        }
	    finally {
		     try {
					if (preparedStmt != null) {
						preparedStmt.close();
					}
					if (conn != null) {
						conn.close();
					}
				} catch (SQLException sqle) {
					return -1;
//					System.out.println("sqle: " + sqle.getMessage());
				}
	    }
	     return 0;	
	}
}