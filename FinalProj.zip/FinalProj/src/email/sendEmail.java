package email;

	import java.util.Properties;

	import javax.mail.Message;
	import javax.mail.MessagingException;
	import javax.mail.Session;
	import javax.mail.Transport;
	import javax.mail.internet.AddressException;
	import javax.mail.internet.InternetAddress;
	import javax.mail.internet.MimeMessage;

	public class sendEmail {

		public static void verificationEmail(String userEmail) {

			String mailSmtpHost = "cakelycakes.com";

			String mailTo = userEmail;
			String mailCc ="";// "littlecakes@cakelycakes.com";
			String mailFrom = "me@here.there.everywhere";
			String mailSubject = "Fast food verify code.";
			String mailText = "Please click on link below";

			sEmail(mailTo, mailCc, mailFrom, mailSubject, mailText, mailSmtpHost);
		}

		public static void sEmail(String to, String cc, String from, String subject, String text, String smtpHost) {
			try {
				Properties properties = new Properties();
				properties.put("mail.smtp.host", smtpHost);
				Session emailSession = Session.getDefaultInstance(properties);

				Message emailMessage = new MimeMessage(emailSession);
				emailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
				emailMessage.addRecipient(Message.RecipientType.CC, new InternetAddress(cc));
				emailMessage.setFrom(new InternetAddress(from));
				emailMessage.setSubject(subject);
				emailMessage.setText(text);

				emailSession.setDebug(true);

				Transport.send(emailMessage);
			} catch (AddressException e) {
				e.printStackTrace();
			} catch (MessagingException e) {
				e.printStackTrace();
			}
		}
//-----------------------------------------------------
		// Java program to send email 
		  
//		import java.util.*; 
//		import javax.mail.*; 
//		import javax.mail.internet.*; 
//		import javax.activation.*; 
//		import javax.mail.Session; 
//		import javax.mail.Transport; 
		  
		  
		   public static void SendTo(String email)  
		   {     
		      // email ID of Recipient. 
		      String recipient = email; 
		  
		      // email ID of  Sender. 
		      String sender = "aarabi56@gmail.com"; 
		  
		      // using host as localhost 
		      String host = "127.0.0.1"; 
		  
		      // Getting system properties 
		      Properties properties = System.getProperties(); 
		  
		      // Setting up mail server 
		      properties.setProperty("mail.smtp.host", host); 
		  
		      // creating session object to get properties 
		      Session session = Session.getDefaultInstance(properties); 
		  
		      try 
		      { 
		         // MimeMessage object. 
		         MimeMessage message = new MimeMessage(session); 
		  
		         // Set From Field: adding senders email to from field. 
		         message.setFrom(new InternetAddress(sender)); 
		  
		         // Set To Field: adding recipient's email to from field. 
		         message.addRecipient(Message.RecipientType.TO, new InternetAddress(recipient)); 
		  
		         // Set Subject: subject of the email 
		         message.setSubject("This is Suject"); 
		  
		         // set body of the email. 
		         message.setText("This is a test mail"); 
		  
		         // Send email. 
		         Transport.send(message); 
		         System.out.println("Mail successfully sent"); 
		      } 
		      catch (MessagingException mex)  
		      { 
		         mex.printStackTrace(); 
		      } 
		   } 
		} 
		//---------------------------------------------------------
