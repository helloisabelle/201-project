package group;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class mongo {
 
	public static void main(String[] args) {
		System.out.println("hello");
		MongoClient client = new MongoClient("localhost", 27017);
		MongoDatabase database = client.getDatabase("mydata");
		MongoCollection<Document> collection = database.getCollection("data");
 
		Document myDoc = collection.find().first();
		client.close();
		System.out.println(myDoc.toJson());
		System.out.println("hello");
	}

 
}