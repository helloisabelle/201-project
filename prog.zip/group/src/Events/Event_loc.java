package Events;


public class Event_loc {
	public String name;
	public double lat;
	public double lon;
	public Event_loc(String name, double lat, double lon){
		this.name = name;
		this.lat = lat;
		this.lon = lon;
	}
}
