package add;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Events.Event;
import group.check;

/**
 * Servlet implementation class e
 */
@WebServlet("/e")
public class e extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public e() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		Integer x = Integer.parseInt(request.getParameter("event"));
		HttpSession s = request.getSession();
		ArrayList<Event> event_array  = (ArrayList<Event>) s.getAttribute("events");
		s.setAttribute("event", event_array.get(x));
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("hi");
		Integer x = Integer.parseInt(request.getParameter("remove"));
		HttpSession s = request.getSession();
		ArrayList<Event> event_array  = (ArrayList<Event>) s.getAttribute("events");
		String title = event_array.get(x).getTitle();
		String username = (String) s.getAttribute("username");
		check.remove(title, username);
	}

}
