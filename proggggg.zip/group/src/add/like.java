package add;

import java.beans.EventSetDescriptor;
import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Events.Event;

/**
 * Servlet implementation class like
 */
@WebServlet("/like")
public class like extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public like() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Event z = null;
		String x = request.getParameter("like");
		HttpSession s = request.getSession();
		ArrayList<Event> event_array  = (ArrayList<Event>) s.getAttribute("events");
		for (int i = 0; i < event_array.size();i++) {
			if (event_array.get(i).getTitle().contentEquals(x)) {
				event_array.get(i).like();
				s.setAttribute("events", event_array);
				//System.out.println("liked" + event_array.get(i).getTitle() + event_array.get(i).getLike());
			}
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
