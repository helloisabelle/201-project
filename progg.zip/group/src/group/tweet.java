package group;

import java.util.Date;

public class tweet {
	public String tweet;
	public String user;
	public Date date;
	public tweet(String tweet, String user, Date date){
		this.tweet = tweet;
		this.user = user;
		this.date = date;
	}
}
