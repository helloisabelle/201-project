package add;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import group.check;
import Events.Event;

/**
 * Servlet implementation class add
 */
@WebServlet("/add")
public class add extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public add() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		Integer x = Integer.parseInt(request.getParameter("eventtoadd"));
		HttpSession s = request.getSession();
		ArrayList<Event> event_array  = (ArrayList<Event>) s.getAttribute("events");
		String title = event_array.get(x).getTitle();
		String username = (String) s.getAttribute("username");
		check.add(title, username);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String x = request.getParameter("event_name");
		HttpSession s = request.getSession();
		ArrayList<Event> event_array  = (ArrayList<Event>) s.getAttribute("events");
		for (Event e: event_array) {
			if (e.getTitle().contentEquals(x)) {
				s.setAttribute("event", e);
			}
		}

	}

}
